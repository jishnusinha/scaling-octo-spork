import { Component, OnInit } from '@angular/core';
import { GotHttpService } from '../got-http.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
public allCharacters;
public allHouses;
public allBooks;
  constructor(public gothttpservice:GotHttpService) { }

  ngOnInit() {
    this.allCharacters=this.gothttpservice.getAllCharacters().subscribe(
      data=>{
       this.allCharacters=data
       
      }
    )


    this.allHouses=this.gothttpservice.getAllHouses().subscribe(
      data=>{
       this.allHouses=data
       
      }
    )
  
    this.allBooks=this.gothttpservice.getAllBooks().subscribe(
      data=>{
       this.allBooks=data
      }
    )
  
  //https://support.edwisor.com/discussions/urR8YZfJy
  
  }

}
