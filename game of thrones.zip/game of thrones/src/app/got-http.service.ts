import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http'
import { Observable } from 'rxjs';@Injectable({
  providedIn: 'root'
})
export class GotHttpService {

  constructor(private http: HttpClient) { }
  public baseUrl = 'https://anapioficeandfire.com/api';
  


  public getAllBooks() {

    let myResponse = this.http.get(this.baseUrl + '/books/');
    return myResponse;

  }
  public getSingleBook(currentBookId) {
    let myResponse = this.http.get(currentBookId);
    return myResponse;


  }

  public getAllCharacters() {

    let myResponse = this.http.get(this.baseUrl + '/characters');
    return myResponse;

  }
  public getSingleCharacter(url) {
    let myResponse = this.http.get(url);
    return myResponse;

  }


  public getAllHouses() {

    let myResponse = this.http.get(this.baseUrl + '/houses/');
    return myResponse;

  }
  public getSingleHouse(currentBookId) {
    let myResponse = this.http.get(currentBookId);
    return myResponse;


  }
}
