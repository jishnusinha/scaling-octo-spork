import { Component, OnInit } from '@angular/core';
import { GotHttpService } from '../got-http.service';

@Component({
  selector: 'app-houses',
  templateUrl: './houses.component.html',
  styleUrls: ['./houses.component.css']
})
export class HousesComponent implements OnInit {
public allHouses;
  constructor(public httpservice:GotHttpService) { }

  ngOnInit() {
  
    this.allHouses=this.httpservice.getAllHouses().subscribe(
      data=>{
       this.allHouses=data
       
      }
    )
  }

}
