import { Component, OnInit, OnDestroy } from '@angular/core';

import { GotHttpService } from '../got-http.service';

import { ActivatedRoute, Router } from '@angular/router';
//import { BlogService } from '../blog.service';

@Component({
  selector: 'app-blog-view',
  templateUrl: './book-view.component.html',
  styleUrls: ['./book-view.component.css']
})
export class BookViewComponent implements OnInit, OnDestroy {
  //empty class
  public currentBook;


  //declare a dummy blog variable here


  



  constructor(private _route: ActivatedRoute, private router: Router,private httpservice:GotHttpService) {

    console.log("constructor is called")


  }

  ngOnInit() {

    console.log("ngonitiscalled")
    //getting blogid from the route
    let bookUrl = this._route.snapshot.paramMap.get('url')
    console.log(bookUrl);
    //calling the function to get the blog with this blogId out of the array
    //this.currentBlog=this.blogservice.getSingleBlogInformation(myBlogId);
    this.httpservice.getSingleBook(bookUrl).subscribe(
    
      data=>{
      console.log(data);
      this.currentBook=data


      }



    );
    
  }
  ngOnDestroy() { 
    
  }
 
}
