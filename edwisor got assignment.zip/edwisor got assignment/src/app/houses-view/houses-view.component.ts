import { Component, OnInit } from '@angular/core';
import { GotHttpService } from '../got-http.service';

import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-houses-view',
  templateUrl: './houses-view.component.html',
  styleUrls: ['./houses-view.component.css']
})
export class HousesViewComponent implements OnInit {

  public currentHouse;
  constructor(private _route: ActivatedRoute, private router: Router,private httpservice:GotHttpService) { }

  ngOnInit() {
  
    console.log("ngonitiscalled")
    //getting blogid from the route
    let houseUrl = this._route.snapshot.paramMap.get('url')
    console.log(houseUrl);
    //calling the function to get the blog with this blogId out of the array
    //this.currentBlog=this.blogservice.getSingleBlogInformation(myBlogId);
    this.httpservice.getSingleBook(houseUrl).subscribe(
    
      data=>{
      console.log(data);
      this.currentHouse=data


      }



    );
  
  
  }

}
