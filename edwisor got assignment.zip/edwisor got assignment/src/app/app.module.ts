import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { CharactersComponent } from './characters/characters.component';
import { HousesComponent } from './houses/houses.component';
//importing httpclient NgModule
// tslint:disable-next-line:import-spacing
import{HttpClientModule}from '@angular/common/http'
//importing router
// tslint:disable-next-line:import-spacing
import{RouterModule, Routes}from '@angular/router'
import { FilterPipe } from './filter.pipe';
import { Filter2Pipe } from './filter2.pipe';
import { BookViewComponent } from './book-view/book-view.component';
import { HousesViewComponent } from './houses-view/houses-view.component';
import { HomeComponent } from './home/home.component';
import { CharacterViewComponent } from './character-view/character-view.component';
@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    CharactersComponent,
    HousesComponent,
    FilterPipe,
    Filter2Pipe,
    BookViewComponent,
    HousesViewComponent,
    HomeComponent,
    CharacterViewComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
   {path: 'books', component: BooksComponent},
   {path: 'books/:url', component: BookViewComponent},
   {path: 'character', component: CharactersComponent},
   {path: 'character/:url', component: CharacterViewComponent},
   {path: 'house', component: HousesComponent},
   {path: 'house/:url', component: HousesViewComponent},
   {path: 'home', component: HomeComponent},
   {path: '', component: HomeComponent},


    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
