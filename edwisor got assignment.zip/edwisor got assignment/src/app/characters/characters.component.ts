import { Component, OnInit } from '@angular/core';
import { GotHttpService } from '../got-http.service';

@Component({
  selector: 'app-characters',
  templateUrl: './characters.component.html',
  styleUrls: ['./characters.component.css']
})
export class CharactersComponent implements OnInit {
public allCharacters;
public allHouses
  constructor(public gothttpservice:GotHttpService) { }

  ngOnInit() {
  
    this.allCharacters=this.gothttpservice.getAllCharacters().subscribe(
      data=>{
       this.allCharacters=data
       
      }
    )
  

   
  }

}
