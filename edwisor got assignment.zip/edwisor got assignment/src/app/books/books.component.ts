import { Component, OnInit } from '@angular/core';
import { GotHttpService } from '../got-http.service';
@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  constructor(public gothttpservice:GotHttpService) { }
public allBooks;
  ngOnInit() {
  
  this.allBooks=this.gothttpservice.getAllBooks().subscribe(
    data=>{
     this.allBooks=data
    }
  )
  
  }

}
