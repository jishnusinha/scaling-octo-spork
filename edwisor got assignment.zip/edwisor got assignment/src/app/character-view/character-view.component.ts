import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GotHttpService } from '../got-http.service';

@Component({
  selector: 'app-character-view',
  templateUrl: './character-view.component.html',
  styleUrls: ['./character-view.component.css']
})
export class CharacterViewComponent implements OnInit {
public currentCharacter;
  constructor(private _route: ActivatedRoute, private router: Router,private httpservice:GotHttpService) { }

  ngOnInit() {
 
 console.log("ngonitiscalled")
    //getting blogid from the route
    let bookUrl = this._route.snapshot.paramMap.get('url')
    console.log(bookUrl);
    //calling the function to get the blog with this blogId out of the array
    //this.currentBlog=this.blogservice.getSingleBlogInformation(myBlogId);
    this.httpservice.getSingleBook(bookUrl).subscribe(
    
      data=>{
      console.log(data);
      this.currentCharacter=data


      }



    );
 
  }

}
